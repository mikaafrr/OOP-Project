package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class LoginScreen extends JPanel{
	private MainFrame main;
	private JTextField username;
	private JTextField password;
	private JButton staffLoginButton;
	private JButton customerLoginButton;
	private JButton registerButton;
	private JLabel failedAttempt;
	public static String custName;
	
	public LoginScreen(MainFrame main)
	{
		setBorder(new LineBorder(new Color(0, 0, 0), 2));
		this.main = main;
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login To Temasek Pizzas!");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(15, 13, 393, 60);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(15, 89, 152, 40);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(15, 142, 152, 40);
		add(lblNewLabel_2);
		
		this.username = new JTextField();
		username.setFont(new Font("Tahoma", Font.PLAIN, 20));
		username.setBounds(156, 90, 232, 40);
		add(username);
		username.setColumns(10);
		
		this.password = new JTextField();
		password.setFont(new Font("Tahoma", Font.PLAIN, 20));
		password.setBounds(156, 144, 232, 40);
		add(password);
		password.setColumns(10);
		
		this.customerLoginButton = new JButton("Customer Login");
		customerLoginButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		customerLoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = username.getText();
				String p = password.getText();
				custName = n;
				boolean validity = main.getController().verifyCustomer(n,p);
				if (validity == true)
				{
					main.showMenuScreen();
				}
				else
				{
					failedAttempt.setText("Wrong details. Please Try Again.");
				}
			}
		});
		customerLoginButton.setBounds(47, 213, 186, 60);
		add(customerLoginButton);
		
		this.staffLoginButton = new JButton("Staff Login");
		staffLoginButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		staffLoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = username.getText();
				String p = password.getText();
				boolean validity = main.getController().verifyStaff(n,p);
				if (validity == true)
				{
					main.showAdminScreen();
				}
				else
				{
					failedAttempt.setText("Wrong details. Please Try Again.");
				}
			}
		});
		staffLoginButton.setBounds(323, 213, 186, 60);
		add(staffLoginButton);
		
		this.registerButton = new JButton("Register");
		registerButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showRegisterScreen();
			}
		});
		registerButton.setBounds(193, 289, 186, 60);
		add(registerButton);
		
		this.failedAttempt = new JLabel(" ");
		failedAttempt.setForeground(Color.RED);
		failedAttempt.setBounds(401, 157, 302, 14);
		add(failedAttempt);
	}
}