package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.Item;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InventoryScreen extends JPanel{
	private MainFrame main;
	private Item[] items;
	private JList invList;
	private JLabel lblItemImage;
	private int index;
	private String selectedImagePath = "";
	
	public InventoryScreen(MainFrame main) {
		this.main = main;
		setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setLayout(null);
		
		JLabel lblInventoryScreen = new JLabel("Inventory");
		lblInventoryScreen.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblInventoryScreen.setBounds(15, 16, 126, 20);
		add(lblInventoryScreen);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 55, 533, 349);
		add(scrollPane);
		
		invList = new JList();
		scrollPane.setViewportView(invList);
		
		JButton btnViewItemsStock = new JButton("View Item");
		btnViewItemsStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				index = invList.getSelectedIndex();
				if (index == -1) {
	                return;
	            }
				Item i = items[index];
				selectedImagePath = i.getImagePath();
                lblItemImage.setIcon(new ImageIcon(i.getImagePath()));
			}
		});
		btnViewItemsStock.setForeground(Color.BLUE);
		btnViewItemsStock.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnViewItemsStock.setBounds(15, 468, 208, 54);
		add(btnViewItemsStock);
		
		lblItemImage = new JLabel("");
		lblItemImage.setBounds(606, 57, 340, 347);
		add(lblItemImage);
		
		JButton btnBackToStaff = new JButton("Back To Staff Menu");
		btnBackToStaff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showAdminScreen();
			}
		});
		btnBackToStaff.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBackToStaff.setBounds(747, 461, 199, 61);
		add(btnBackToStaff);
		
		populateInvList();

	}
	
	private void populateInvList() {
        this.items = this.main.getController().getAllItems(); // Get all items from the controller
        DefaultListModel model = new DefaultListModel(); // Create a new list model
        for (int i = 0; i < items.length; i++) {
            Item op = items[i]; // Get the item
            model.addElement(op.getName() + " - $" + op.getPrice() + " - " + op.getQuantity()); // Add the item to the model
        }
        this.invList.setModel(model); // Set the model for the inventory list
    }
}
