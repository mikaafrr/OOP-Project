package gui;

import javax.swing.JPanel;
import controller.MainFrame;
import data.Item;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class CheckOrderScreen extends JPanel {
    private MainFrame main;
    private List<Item> selectedItems = new ArrayList<>();
    private JLabel lblItemName, lblItemImage, lblDrinkName, lblDrinkImage;
    private JButton btnDecQuan, btnIcrQuan, btnAddToCart;
    private JLabel lblOrderQuan;
    private int quantity = 1;
    private Item foodItem;
    private Item drinkItem;
    private JButton btnBackToMenu;

    public CheckOrderScreen(MainFrame main, Item foodItem, Item drinkItem) {
        setBorder(new LineBorder(new Color(0, 0, 0), 2)); 
        setBackground(new Color(240, 240, 240)); 
        this.main = main; 
        this.foodItem = foodItem; 
        this.drinkItem = drinkItem; 
        setLayout(null);

        // Create and add the label for "Add To Cart"
        JLabel lblAddToCart = new JLabel("Add To Cart");
        lblAddToCart.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblAddToCart.setBounds(15, 16, 213, 46);
        add(lblAddToCart);

        // If there is a food item, display its name and image
        if (foodItem != null) {
            lblItemName = new JLabel(foodItem.getName());
            lblItemName.setFont(new Font("Tahoma", Font.BOLD, 18));
            lblItemName.setBounds(15, 103, 213, 131);
            add(lblItemName);

            lblItemImage = new JLabel(new ImageIcon(foodItem.getImagePath()));
            lblItemImage.setBounds(334, 103, 213, 131);
            add(lblItemImage);

            selectedItems.add(new Item(foodItem.getName(), foodItem.getPrice(), quantity, foodItem.getImagePath()));
        }

        // If there is a drink item, display its name and image
        if (drinkItem != null) {
            lblDrinkName = new JLabel(drinkItem.getName());
            lblDrinkName.setFont(new Font("Tahoma", Font.BOLD, 18));
            lblDrinkName.setBounds(15, 269, 213, 131);
            add(lblDrinkName);

            lblDrinkImage = new JLabel(new ImageIcon(drinkItem.getImagePath()));
            lblDrinkImage.setBounds(334, 269, 213, 131);
            add(lblDrinkImage);

            selectedItems.add(new Item(drinkItem.getName(), drinkItem.getPrice(), quantity, drinkItem.getImagePath()));
        }

        // Create and add the button to decrease quantity
        btnDecQuan = new JButton("<");
        btnDecQuan.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnDecQuan.setBounds(635, 247, 59, 29);
        btnDecQuan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (quantity > 1) {
                    quantity--; // Decrease the quantity
                    lblOrderQuan.setText(String.valueOf(quantity)); // Update the label to show the new quantity
                    updateQuantities(); // Update the quantities in the selected items
                }
            }
        });
        add(btnDecQuan);

        // Create and add the button to increase quantity
        btnIcrQuan = new JButton(">");
        btnIcrQuan.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnIcrQuan.setBounds(797, 247, 59, 29);
        btnIcrQuan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                quantity++; // Increase the quantity
                lblOrderQuan.setText(String.valueOf(quantity)); // Update the label to show the new quantity
                updateQuantities(); // Update the quantities in the selected items
            }
        });
        add(btnIcrQuan);

        // Create and add the label to show the current quantity
        lblOrderQuan = new JLabel(String.valueOf(quantity));
        lblOrderQuan.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblOrderQuan.setHorizontalAlignment(SwingConstants.CENTER);
        lblOrderQuan.setBounds(709, 251, 69, 20);
        add(lblOrderQuan);

        // Create and add the button to add items to the cart
        btnAddToCart = new JButton("Add to Cart");
        btnAddToCart.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnAddToCart.setBounds(635, 314, 221, 46);
        btnAddToCart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addToCart(); // Call the method to add items to the cart
            }
        });
        add(btnAddToCart);
        
        // Create and add the button to go back to the menu
        btnBackToMenu = new JButton("Back To Menu");
        btnBackToMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                main.showMenuScreen(); // Show the menu screen
            }
        });
        btnBackToMenu.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnBackToMenu.setBounds(718, 16, 166, 46);
        add(btnBackToMenu);
    }

    // Update the quantities in the selected items
    private void updateQuantities() {
        for (Item item : selectedItems) {
            item.setQuantity(quantity); // Set the new quantity for each item
        }
    }

    // Add items to the cart
    private void addToCart() {
        boolean foodInStock = true;
        boolean drinkInStock = true;

        // Check food item stock if food item is not null
        if (foodItem != null) {
            int foodQuan = foodItem.getQuantity();
            foodInStock = foodQuan >= quantity; // Check if the food item is in stock
        }
        
        // Check drink item stock if drink item is not null
        if (drinkItem != null) {
            int drinkQuan = drinkItem.getQuantity();
            drinkInStock = drinkQuan >= quantity; // Check if the drink item is in stock
        }

        // Proceed if both items are in stock or if one of the items is not selected (null)
        if ((foodItem == null || foodInStock) && (drinkItem == null || drinkInStock)) {
            if (!selectedItems.isEmpty()) {
                StringBuilder message = new StringBuilder("Added to Cart:\n");

                for (Item item : selectedItems) {
                    main.getController().addToCart(item); // Use controller to manage the cart
                    message.append(item.getName()).append(" (Qty: ").append(item.getQuantity()).append(" (Price: ")
                            .append(item.getPrice()).append("))\n");
                }

                // Do not update the stock in the inventory here
                // Decrementing quantities here is redundant

                JOptionPane.showMessageDialog(CheckOrderScreen.this, message.toString()); // Show a message indicating the items added to the cart
            }
        } else {
            JOptionPane.showMessageDialog(CheckOrderScreen.this, "Not Enough Stock"); // Show a message if not enough stock
        }

        main.showMenuScreen(); // Show the menu screen
    }

}
