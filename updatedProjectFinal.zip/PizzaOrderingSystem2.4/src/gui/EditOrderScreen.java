	package gui;
	
	import javax.swing.JPanel;
	
	import controller.MainFrame;
	import data.Item;
	import data.Order;
	
	import javax.swing.JLabel;
	import javax.swing.JScrollPane;
	import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListModel;
	import javax.swing.DefaultListModel;
	import javax.swing.JButton;
	import java.awt.Font;
	import java.awt.Color;
	import javax.swing.JTextField;
	import java.awt.Component;
	import java.awt.event.ActionListener;
	import java.util.List;
	import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.LineBorder;
	
	public class EditOrderScreen extends JPanel{
		private MainFrame main;
		
		private JList<String> orderList;
		private JList<String> itemsOrderList;
		private Item[] items;
		private Order[] order;
		
		private JTextField newQuantity;
		
		private JButton btnDeleteOrder;
		private JButton btnSelectOrder;
		private JButton btnUpdateOrder;
		
	
		
		private String custName;

		private JLabel lblSelectedItemName;

		private JLabel lblSelectedItemQuantity;

		private JLabel lblSelectedItemPrice;
		
		public EditOrderScreen(MainFrame main) {
			setBorder(new LineBorder(new Color(0, 0, 0), 2));
			this.main = main;
			setLayout(null);
			
			JLabel label = new JLabel("OrderIDs");
			label.setBounds(10, 11, 106, 16);
			add(label);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(34, 69, 286, 134);
			add(scrollPane);
			
			this.orderList = new JList<String>();
			scrollPane.setViewportView(orderList);
			
			
			this.btnDeleteOrder = new JButton("Delete");
			btnDeleteOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					int index = orderList.getSelectedIndex();
					if (index!=-1)
					{
						int choice = JOptionPane.showConfirmDialog(EditOrderScreen.this,"Are you sure you want to delete the selected order?", "Confirmation", JOptionPane.YES_NO_OPTION);
						if (choice == JOptionPane.YES_OPTION) {
							main.getController().deleteOrder(index);
							populateOrderList();
					}
				}
					else
					{
						JOptionPane.showMessageDialog(EditOrderScreen.this, "Please select an order to delete.");
					}
				}
			});
			btnDeleteOrder.setForeground(Color.RED);
			btnDeleteOrder.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnDeleteOrder.setBounds(34, 214, 97, 25);
			add(btnDeleteOrder);
			
			this.btnSelectOrder = new JButton("Edit Order");
			btnSelectOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					populateItemsOrderList();
				}
			});
			btnSelectOrder.setForeground(Color.BLUE);
			btnSelectOrder.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnSelectOrder.setBounds(190, 214, 130, 25);
			add(btnSelectOrder);
			
			this.lblSelectedItemName = new JLabel("Selected Item Name:");
			lblSelectedItemName.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblSelectedItemName.setBounds(34, 283, 426, 25);
			add(lblSelectedItemName);
			
			this.lblSelectedItemQuantity = new JLabel("Selected Item Quantity:");
			lblSelectedItemQuantity.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblSelectedItemQuantity.setBounds(34, 319, 426, 25);
			add(lblSelectedItemQuantity);
			
			this.lblSelectedItemPrice = new JLabel("Selected Item Price:");
			lblSelectedItemPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblSelectedItemPrice.setBounds(34, 355, 426, 25);
			add(lblSelectedItemPrice);
			
			JScrollPane scrollPane_1 = new JScrollPane((Component) null);
			scrollPane_1.setBounds(395, 69, 286, 134);
			add(scrollPane_1);
			
			this.itemsOrderList = new JList<String>();
			itemsOrderList.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					if (e.getClickCount()==2){
						int indexItems = itemsOrderList.getSelectedIndex();
						int indexOrders = orderList.getSelectedIndex();
						if (indexItems!=-1){
							Order[] allOrders = main.getController().getAllOrders();
							Order selectedOrder = allOrders[indexOrders];
							Item selectedItem = selectedOrder.getItems().get(indexItems);
							
							String name = selectedItem.getName();
							String price = Double.valueOf(selectedItem.getPrice()).toString();
							String quantity = Integer.valueOf(selectedItem.getQuantity()).toString();
											
							lblSelectedItemName.setText("Selected Item Name: " + name);
							lblSelectedItemQuantity.setText("Selected Item Quantity: " + quantity);
							lblSelectedItemPrice.setText("Selected Item Price: " + price);
						}
					}
				}
			});
			scrollPane_1.setViewportView(itemsOrderList);
			
			this.btnUpdateOrder = new JButton("Update Order Item");
			btnUpdateOrder.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent arg0) {
			        int indexItems = itemsOrderList.getSelectedIndex();
			        int indexOrders = orderList.getSelectedIndex();
			        int newQuan = Integer.valueOf(newQuantity.getText());

			        if (indexItems != -1 && indexOrders != -1) {
			            Order[] allOrders = main.getController().getAllOrders();
			            Order selectedOrder = allOrders[indexOrders];
			            Item selectedItem = selectedOrder.getItems().get(indexItems);
			            int origQuan = selectedItem.getQuantity();
			            String selectedItemName = selectedItem.getName();
			            Item item = main.getController().findItemByName(selectedItemName);

			            // Calculate the stock difference
			            int stockDifference = newQuan - origQuan;

			            // Check if the new quantity is available in stock
			            if (item.getQuantity() >= stockDifference) {
			                // Update the item quantity in the order
			                selectedItem.setQuantity(newQuan);

			                // Update the inventory
			                item.setQuantity(item.getQuantity() - stockDifference);

			                JOptionPane.showMessageDialog(EditOrderScreen.this, "Order item updated successfully.");
			                populateItemsOrderList();
			            } else {
			                JOptionPane.showMessageDialog(EditOrderScreen.this, "Not enough stock available.");
			            }
			        } else {
			            JOptionPane.showMessageDialog(EditOrderScreen.this, "Please select an order item to update.");
			        }
			    }
			});
			btnUpdateOrder.setForeground(new Color(255, 105, 180));
			btnUpdateOrder.setFont(new Font("Tahoma", Font.PLAIN, 20));
			btnUpdateOrder.setBackground(Color.WHITE);
			btnUpdateOrder.setBounds(395, 222, 286, 50);
			add(btnUpdateOrder);

			btnUpdateOrder.setForeground(new Color(255, 105, 180));
			btnUpdateOrder.setFont(new Font("Tahoma", Font.PLAIN, 20));
			btnUpdateOrder.setBackground(Color.WHITE);
			btnUpdateOrder.setBounds(395, 222, 286, 50);
			add(btnUpdateOrder);
			
			JLabel label_1 = new JLabel("New Quantity:");
			label_1.setForeground(new Color(255, 105, 180));
			label_1.setFont(new Font("Tahoma", Font.BOLD, 15));
			label_1.setBounds(34, 397, 148, 20);
			add(label_1);
			
			this.newQuantity = new JTextField();
			newQuantity.setFont(new Font("Tahoma", Font.PLAIN, 15));
			newQuantity.setColumns(10);
			newQuantity.setBounds(172, 395, 148, 26);
			add(newQuantity);
			
			JButton btnNewButton = new JButton("Back To Menu");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					main.showMenuScreen();
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
			btnNewButton.setForeground(new Color(0, 0, 0));
			btnNewButton.setBounds(519, 375, 162, 45);
			add(btnNewButton);
			this.populateOrderList();
		}
		
		
		private void populateOrderList()
		{
			this.order = this.main.getController().getAllOrders();
			DefaultListModel model = new DefaultListModel();
			for (int i=0; i<order.length;i++)
			{
				Order or = order[i];
				model.addElement(or.getOrderID());
			}
			this.orderList.setModel(model);
		}
		
		private void populateItemsOrderList() {
			Order[] or = this.main.getController().getAllOrders();
	        int index = orderList.getSelectedIndex();
	        if (index >= 0) {
	            Order selectedOrder = or[index];
	            List<Item> items = selectedOrder.getItems();
	            DefaultListModel<String> model = new DefaultListModel<String>();
	            for (Item item : items) {
	                model.addElement(item.getName() + " " + item.getPrice() + " " + item.getQuantity());
	            }
	            this.itemsOrderList.setModel(model);
	        } else {
	            JOptionPane.showMessageDialog(this, "No order selected.");
	        }
	    }
	}
