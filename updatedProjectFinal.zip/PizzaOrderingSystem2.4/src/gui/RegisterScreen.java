package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.Customer;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class RegisterScreen extends JPanel {
	private MainFrame main;
	private JTextField username;
	private JTextField password;
	private JButton staffRegisterButton;
	private JButton customerRegisterButton;
	private JButton backToLoginButton;
	private Customer[] user;
	private JLabel successfulRegister;
	
	public RegisterScreen(MainFrame main)
	{
		setBorder(new LineBorder(new Color(0, 0, 0), 2));
		this.main = main;
		setLayout(null);
		
		JLabel lblLogin = new JLabel("Register");
		lblLogin.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblLogin.setBounds(15, 13, 393, 60);
		add(lblLogin);
		
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUsername.setBounds(15, 89, 152, 40);
		add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPassword.setBounds(15, 142, 152, 40);
		add(lblPassword);
		
		this.username = new JTextField();
		username.setBounds(156, 90, 232, 40);
		add(username);
		username.setColumns(10);
		
		this.password = new JTextField();
		password.setBounds(156, 144, 232, 40);
		add(password);
		password.setColumns(10);
		
		this.staffRegisterButton = new JButton("Staff Register");
		staffRegisterButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		staffRegisterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = username.getText();
				String pass = password.getText();
				
				main.getController().registerStaff(user,pass);
				successfulRegister.setText("Successful Register!");
				username.setText("");
				password.setText("");
			}
		});
		staffRegisterButton.setBounds(323, 213, 186, 60);
		add(staffRegisterButton);
		
		this.customerRegisterButton = new JButton("Customer Register");
		customerRegisterButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		customerRegisterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = username.getText();
				String pass = password.getText();
				
				main.getController().registerCustomers(user,pass);
				successfulRegister.setText("Successful Register!");
				username.setText("");
				password.setText("");
			}
		});
		customerRegisterButton.setBounds(47, 213, 186, 60);
		add(customerRegisterButton);
		
		this.backToLoginButton = new JButton("Back To Login");
		backToLoginButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		backToLoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showLoginScreen();
			}
		});
		backToLoginButton.setBounds(193, 289, 186, 60);
		add(backToLoginButton);
		
		this.successfulRegister = new JLabel("");
		successfulRegister.setForeground(new Color(154, 205, 50));
		successfulRegister.setBounds(310, 111, 201, 14);
		add(successfulRegister);
	}

}
