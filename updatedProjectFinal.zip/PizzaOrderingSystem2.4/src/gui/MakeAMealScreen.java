package gui;

import javax.swing.JPanel;
import controller.MainFrame;
import data.Item;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.SwingConstants;

public class MakeAMealScreen extends JPanel {
    private MainFrame main;
    private Item selectedItem;
    private JButton btnDrink1, btnDrink2, btnDrink3, btnDrink4, btnDrink5, btnDrink6;
    private JLabel lblDrink1, lblDrink2, lblDrink3, lblDrink4, lblDrink5, lblDrink6;

    public MakeAMealScreen(MainFrame main, Item selectedItem) {
        setBorder(new LineBorder(new Color(0, 0, 0), 2)); // Set the border of the panel
        this.main = main; // Set the main frame
        this.selectedItem = selectedItem; // Set the selected item
        setLayout(null); // Set the layout to null

        // Create and add the label for "Customise Your Meal"
        JLabel lblMakeAMeal = new JLabel("Customise Your Meal");
        lblMakeAMeal.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblMakeAMeal.setBounds(15, 16, 282, 46);
        add(lblMakeAMeal);

        // Create and add the label for the item name
        JLabel lblItemName = new JLabel(selectedItem.getName());
        lblItemName.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblItemName.setBounds(45, 78, 252, 149);
        add(lblItemName);

        // Create and add the label for the item image
        JLabel lblItemImage = new JLabel(new ImageIcon(selectedItem.getImagePath()));
        lblItemImage.setBounds(363, 78, 189, 149);
        add(lblItemImage);

        // Create and add the label for drinks prompt
        JLabel lblDrinks = new JLabel("Would You Like To Make A Meal?");
        lblDrinks.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblDrinks.setBounds(45, 243, 344, 20);
        add(lblDrinks);

        // Create and add buttons for each drink option
        btnDrink1 = new JButton("");
        btnDrink1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                Item drinkItem = main.getController().getDrinks()[0]; // Get the first drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink1.setBounds(45, 279, 132, 128);
        btnDrink1.setVisible(false); // Initially set button to not visible
        add(btnDrink1);

        btnDrink2 = new JButton("");
        btnDrink2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Item drinkItem = main.getController().getDrinks()[1]; // Get the second drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink2.setBounds(220, 279, 132, 128);
        btnDrink2.setVisible(false); // Initially set button to not visible
        add(btnDrink2);

        btnDrink3 = new JButton("");
        btnDrink3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Item drinkItem = main.getController().getDrinks()[2]; // Get the third drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink3.setBounds(397, 279, 132, 128);
        btnDrink3.setVisible(false); // Initially set button to not visible
        add(btnDrink3);

        btnDrink4 = new JButton("");
        btnDrink4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Item drinkItem = main.getController().getDrinks()[3]; // Get the fourth drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink4.setBounds(575, 279, 132, 128);
        btnDrink4.setVisible(false); // Initially set button to not visible
        add(btnDrink4);
        
        btnDrink5 = new JButton("");
        btnDrink5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                Item drinkItem = main.getController().getDrinks()[4]; // Get the fifth drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink5.setBounds(757, 279, 132, 128);
        btnDrink5.setVisible(false); // Initially set button to not visible
        add(btnDrink5);
        
        btnDrink6 = new JButton("");
        btnDrink6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Item drinkItem = main.getController().getDrinks()[5]; // Get the sixth drink item
                main.showCheckOrderScreen(selectedItem, drinkItem); // Show check order screen with selected item and drink item
            }
        });
        btnDrink6.setBounds(940, 279, 132, 128);
        btnDrink6.setVisible(false); // Initially set button to not visible
        add(btnDrink6);

        // Create and add the button to go back to the menu
        JButton btnBackToMenu = new JButton("Back To Menu");
        btnBackToMenu.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnBackToMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                main.showMenuScreen(); // Show the menu screen
            }
        });
        btnBackToMenu.setBounds(718, 16, 166, 46);
        add(btnBackToMenu);

        // Create and add the button for no meal option
        JButton btnNoDrink = new JButton("NO MEAL");
        btnNoDrink.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                main.showCheckOrderScreen(selectedItem, null); // Show check order screen with selected item and no drink
            }
        });
        btnNoDrink.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnNoDrink.setBounds(45, 479, 218, 74);
        add(btnNoDrink);
        
        // Create and add labels for each drink option
        lblDrink1 = new JLabel("");
        lblDrink1.setBounds(45, 423, 132, 28);
        add(lblDrink1);
        
        lblDrink2 = new JLabel("");
        lblDrink2.setBounds(220, 423, 132, 28);
        add(lblDrink2);
        
        lblDrink3 = new JLabel("");
        lblDrink3.setBounds(397, 423, 132, 28);
        add(lblDrink3);
        
        lblDrink4 = new JLabel("");
        lblDrink4.setBounds(575, 423, 132, 28);
        add(lblDrink4);
        
        lblDrink5 = new JLabel("");
        lblDrink5.setBounds(757, 423, 132, 28);
        add(lblDrink5);
        
        lblDrink6 = new JLabel("");
        lblDrink6.setBounds(940, 423, 132, 28);
        add(lblDrink6);

        this.populateDrinkButtons(); // Call method to populate drink buttons
    }

    private void populateDrinkButtons() {
        JButton[] drinkButtons = { btnDrink1, btnDrink2, btnDrink3, btnDrink4, btnDrink5, btnDrink6 };
        JLabel[] lblDrinks = { lblDrink1, lblDrink2, lblDrink3, lblDrink4, lblDrink5, lblDrink6 };
        int drinkIndex = 0;
        Item[] drinks = main.getController().getDrinks(); // Get the list of drinks from the controller
        for (Item item : drinks) {
            if (drinkIndex < drinkButtons.length) {
                drinkButtons[drinkIndex].setIcon(new ImageIcon(item.getImagePath())); // Set drink image
                drinkButtons[drinkIndex].setText("<html>" + item.getName() + "<br>$" + item.getPrice() + "<br>Qty: " + item.getQuantity() + "</html>"); // Set drink details
                lblDrinks[drinkIndex].setText(item.getName()); // Set drink name label
                drinkButtons[drinkIndex].setVisible(true); // Make the button visible
                drinkIndex++;
            }
        }
    }
}
