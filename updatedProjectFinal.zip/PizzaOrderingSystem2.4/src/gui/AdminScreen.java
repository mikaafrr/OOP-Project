package gui;

import javax.swing.JPanel;

import controller.MainFrame;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class AdminScreen extends JPanel{
	
	private MainFrame main;
	private JComboBox<String> cbPage;
	private JLabel lblImage;
	
	public AdminScreen(MainFrame main) {
		setBorder(new LineBorder(new Color(0, 0, 0), 2));
		this.main = main;
		setLayout(null);
		String[] valArr = {"Edit Item Screen", "Summary Screen", "Inventory Screen"};
		
		JLabel lblAdmin = new JLabel("Admin");
		lblAdmin.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblAdmin.setBounds(10, 11, 87, 29);
		add(lblAdmin);
		
		this.cbPage = new JComboBox(valArr);
		cbPage.setFont(new Font("Tahoma", Font.BOLD, 20));
		cbPage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedPage = cbPage.getSelectedItem().toString();				
                switch (selectedPage) {
                    case "Edit Item Screen":
                        lblImage.setIcon(new ImageIcon("C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\EditItemScreen.jpeg"));
                        break;
                    case "Summary Screen":
                        lblImage.setIcon(new ImageIcon("C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\SummaryScreen.jpeg"));
                        break;
                    case "Inventory Screen":
                        lblImage.setIcon(new ImageIcon("C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\Inventory.jpeg"));
                        break;
                    default:
                        lblImage.setIcon(null);
                        break;
                }
			}
		});
		cbPage.setBounds(15, 665, 916, 56);
		add(cbPage);
		
		JButton button = new JButton("Go To Page");
		button.setFont(new Font("Tahoma", Font.BOLD, 18));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String page = cbPage.getSelectedItem().toString();
				if (page == "Edit Item Screen"){
					main.showEditItemScreen();
				}
				else if (page == "Summary Screen"){
					main.showSummaryScreen();
				}
				else if (page == "Inventory Screen"){
					main.showInventoryScreen();
				}
			}
		});
		button.setBounds(10, 737, 250, 40);
		add(button);
		
		JButton button_1 = new JButton("Signout");
		button_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showLoginScreen();
			}
		});
		button_1.setBounds(681, 737, 250, 40);
		add(button_1);
		
		
		lblImage = new JLabel("");
		lblImage.setBounds(20, 56, 911, 593);
		Border blackline = BorderFactory.createLineBorder(Color.black, 3);
		lblImage.setBorder(blackline);
		lblImage.setIcon(new ImageIcon("C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\EditItemScreen.jpeg"));
		add(lblImage);
	}
}
