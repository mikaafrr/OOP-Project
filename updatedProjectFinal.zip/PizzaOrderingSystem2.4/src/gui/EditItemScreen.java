package gui;

import javax.swing.JPanel;
import controller.MainFrame;
import data.Item;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

public class EditItemScreen extends JPanel {
    private MainFrame main;
    private JTextField txtEnterName;
    private JTextField txtEnterPrice;
    private JTextField txtEnterQuan;
    private Item[] items;
    private JList itemList;
    private int index;
    private JLabel lblItemImage;
    private String selectedImagePath = "";

   
    public EditItemScreen(MainFrame main) {
        this.main = main; 
        setBorder(new LineBorder(new Color(0, 0, 0), 2)); 
        setLayout(null); 

        // Label for the edit item screen title
        JLabel lblEditItemScreen = new JLabel("Edit Item Screen");
        lblEditItemScreen.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblEditItemScreen.setBounds(15, 16, 181, 20);
        add(lblEditItemScreen);

        // Scroll pane for the item list
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(15, 70, 580, 214);
        add(scrollPane);

        // JList to display the items
        this.itemList = new JList();
        itemList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) { // Check if the value is adjusting
                    index = itemList.getSelectedIndex(); // Get the selected index
                    if (index == -1) {
                        return;
                    }
                    Item i = items[index]; // Get the selected item
                    txtEnterName.setText(i.getName()); // Set the name field
                    txtEnterPrice.setText(String.valueOf(i.getPrice())); // Set the price field
                    txtEnterQuan.setText(String.valueOf(i.getQuantity())); // Set the quantity field
                    selectedImagePath = i.getImagePath(); // Set the image path
                    lblItemImage.setIcon(new ImageIcon(i.getImagePath())); // Set the image icon
                }
            }
        });

        scrollPane.setViewportView(itemList); 

        // Label for the item name
        JLabel lblName = new JLabel("Name:");
        lblName.setForeground(Color.BLUE);
        lblName.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblName.setBounds(15, 320, 96, 20);
        add(lblName);

        // Label for the item price
        JLabel lblPrice = new JLabel("Price:");
        lblPrice.setForeground(Color.BLUE);
        lblPrice.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblPrice.setBounds(15, 397, 96, 20);
        add(lblPrice);

        // Label for the item quantity
        JLabel lblQuantity = new JLabel("Quantity:");
        lblQuantity.setForeground(Color.BLUE);
        lblQuantity.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblQuantity.setBounds(15, 478, 96, 20);
        add(lblQuantity);

        // Text field for entering the item name
        txtEnterName = new JTextField();
        txtEnterName.setBounds(150, 319, 181, 26);
        add(txtEnterName);
        txtEnterName.setColumns(10);

        // Text field for entering the item price
        txtEnterPrice = new JTextField();
        txtEnterPrice.setBounds(150, 396, 181, 26);
        add(txtEnterPrice);
        txtEnterPrice.setColumns(10);

        // Text field for entering the item quantity
        txtEnterQuan = new JTextField();
        txtEnterQuan.setBounds(150, 477, 181, 26);
        add(txtEnterQuan);
        txtEnterQuan.setColumns(10);

        // Button to update an item
        JButton btnUpdate = new JButton("Update");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtEnterName.getText(); // Get the entered name
                double price = Double.valueOf(txtEnterPrice.getText()); // Get the entered price
                int quantity = Integer.valueOf(txtEnterQuan.getText()); // Get the entered quantity
                Item newItem = new Item(name, price, quantity, selectedImagePath); // Create a new item
                main.getController().editItems(index, newItem); // Update the item in the controller
                populateItemsList(); // Refresh the item list
            }
        });
        btnUpdate.setForeground(Color.BLUE);
        btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnUpdate.setBounds(15, 549, 133, 45);
        add(btnUpdate);

        // Button to add a new item
        JButton btnAddItem = new JButton("Add Item");
        btnAddItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtEnterName.getText(); // Get the entered name
                double price = Double.valueOf(txtEnterPrice.getText()); // Get the entered price
                int quantity = Integer.valueOf(txtEnterQuan.getText()); // Get the entered quantity
                Item newItem = new Item(name, price, quantity, selectedImagePath); // Create a new item
                if (main.getController().itemExists(name)) { // Check if the item already exists
                    JOptionPane.showMessageDialog(EditItemScreen.this, name + " already exists", "Duplicate Item", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                main.getController().addItem(name, price, quantity, selectedImagePath); // Add the item to the controller

                populateItemsList(); // Refresh the item list
                txtEnterName.setText(""); // Clear the name field
                txtEnterPrice.setText(""); // Clear the price field
                txtEnterQuan.setText(""); // Clear the quantity field
                selectedImagePath = ""; // Clear the image path
                lblItemImage.setIcon(null); // Clear the image icon
            }
        });
        btnAddItem.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnAddItem.setBounds(198, 549, 133, 45);
        add(btnAddItem);

        // Button to delete an item
        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                index = itemList.getSelectedIndex(); // Get the selected index
                if (index == -1) {
                    return;
                }
                main.getController().deleteItem(index); // Delete the item in the controller
                populateItemsList(); // Refresh the item list
                txtEnterPrice.setText(""); // Clear the price field
                txtEnterName.setText(""); // Clear the name field
                txtEnterQuan.setText(""); // Clear the quantity field
            }
        });
        btnDelete.setForeground(Color.RED);
        btnDelete.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnDelete.setBounds(380, 549, 133, 45);
        add(btnDelete);

        // Button to go back to the staff menu
        JButton btnBackToStaff = new JButton("Back To Staff Menu");
        btnBackToStaff.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnBackToStaff.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                main.showAdminScreen(); // Show the admin screen
            }
        });
        btnBackToStaff.setBounds(719, 525, 211, 69);
        add(btnBackToStaff);

        // Label for the item image
        lblItemImage = new JLabel("");
        lblItemImage.setBounds(628, 48, 278, 267);
        add(lblItemImage);

        // Button to add an image to an item
        JButton btnNewButton = new JButton("Add Image");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // Only allow file selection
                int option = fileChooser.showOpenDialog(EditItemScreen.this); // Show the file chooser dialog
                if (option == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile(); // Get the selected file
                    selectedImagePath = file.getAbsolutePath(); // Get the file path
                    lblItemImage.setIcon(new ImageIcon(selectedImagePath)); // Set the image icon
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnNewButton.setBounds(550, 549, 154, 45);
        add(btnNewButton);

        this.populateItemsList(); // Populate the item list
    }

    // Method to populate the item list
    private void populateItemsList() {
        this.items = this.main.getController().getAllItems(); // Get all items from the controller
        DefaultListModel model = new DefaultListModel(); // Create a new list model
        for (int i = 0; i < items.length; i++) {
            Item op = items[i]; // Get the item
            model.addElement(op.getName() + " " + op.getPrice() + " " + op.getQuantity()); // Add the item to the model
        }
        this.itemList.setModel(model); // Set the model for the item list
    }
}
