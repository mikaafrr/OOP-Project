package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.border.LineBorder;

import Utility.Time;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import controller.MainFrame;
import data.Item;
import data.Order;

public class SummaryScreen extends JPanel {

    private MainFrame main; 
    private Order[] orders; 
    private Item[] items; 
    private JLabel lblTotalSales; 
    private DefaultListModel<String> itemsSoldListModel; 
    private DefaultListModel<String> ordersListModel;
    private JList<String> itemsSoldList;
    private JList<String> ordersList;

    public SummaryScreen(MainFrame main) {
        this.main = main;
        setBorder(new LineBorder(new Color(0, 0, 0), 2));
        setLayout(null); 

        // Label for the screen title
        JLabel lblNewLabel = new JLabel("Summary Screen");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(15, 16, 180, 20);
        add(lblNewLabel);

        // Label for items sale summary
        JLabel lblNewLabel_1 = new JLabel("Sale Summary Of Items");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1.setBounds(167, 70, 203, 20);
        add(lblNewLabel_1);

        // Scroll pane for items sold list
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(38, 106, 471, 220);
        add(scrollPane);

        itemsSoldListModel = new DefaultListModel<>();
        itemsSoldList = new JList<>(itemsSoldListModel);
        scrollPane.setViewportView(itemsSoldList);

        // Label for total sales
        lblTotalSales = new JLabel("Total Sales: ");
        lblTotalSales.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblTotalSales.setBounds(110, 382, 248, 20);
        add(lblTotalSales);

        // Button to calculate total sales
        JButton btnCalculateTotalSales = new JButton("Calculate Total Sales");
        btnCalculateTotalSales.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculateTotalSales(); // Call calculate total sales method when button is clicked
            }
        });
        btnCalculateTotalSales.setForeground(Color.BLUE);
        btnCalculateTotalSales.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnCalculateTotalSales.setBounds(110, 437, 248, 47);
        add(btnCalculateTotalSales);

        // Scroll pane for orders list
        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(639, 106, 264, 378);
        add(scrollPane_1);

        ordersListModel = new DefaultListModel<>(); 
        ordersList = new JList<>(ordersListModel); 
        scrollPane_1.setViewportView(ordersList); 

        // Label for order summary
        JLabel lblSummary = new JLabel("Selected Order Summary");
        lblSummary.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblSummary.setBounds(666, 70, 220, 20);
        add(lblSummary);
        
        // Button to go back to staff menu
        JButton btnBackToStaff = new JButton("Back To Staff Menu");
        btnBackToStaff.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		main.showAdminScreen(); // Show admin screen when button is clicked
        	}
        });
        btnBackToStaff.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnBackToStaff.setBounds(15, 500, 220, 47);
        add(btnBackToStaff);

        populateItemsSoldList(); // Populate items sold list
        populateOrdersList(); // Populate orders list
    }

    // Method to populate items sold list
    private void populateItemsSoldList() {
        this.orders = this.main.getController().getAllOrders(); // Get all orders
        itemsSoldListModel.clear(); // Clear the current list
        for (Order order : orders) { // Iterate through all orders
            for (Item item : order.getItems()) { // Go through items in each order
                boolean itemExists = false; // To check if item exists in the list
                for (int k = 0; k < itemsSoldListModel.getSize(); k++) { // Go through current list items
                    String listItem = itemsSoldListModel.get(k);
                    if (listItem.startsWith(item.getName())) { // If item exists, update the quantity
                        int quantityIndex = listItem.lastIndexOf(": ") + 2;
                        int currentQuantity = Integer.parseInt(listItem.substring(quantityIndex));
                        int newQuantity = currentQuantity + item.getQuantity();
                        itemsSoldListModel.set(k, item.getName() + " | Total Quantity: " + newQuantity);
                        itemExists = true;
                        break;
                    }
                }
                if (!itemExists) { // If item does not exist, add it to the list
                    itemsSoldListModel.addElement(item.getName() + " | Total Quantity: " + item.getQuantity());
                }
            }
        }
    }

    // Method to populate orders list
    private void populateOrdersList() {
        this.orders = this.main.getController().getAllOrders(); // Get all orders
        ordersListModel.clear(); // Clear the current list
        for (Order order : orders) { // Go through all orders
            String orderDetails = "<html>Order Number: " + order.getOrderID() + "<br>" + // Order number
                                  "Created by: " + order.getCreatedByCustomer() + "<br>" + // Customer who created the order
                                  "Time Ordered: " + Time.getCurrentTime() + "<br>" + // Time of the order
                                  "Order Details:<br>";
            for (Item item : order.getItems()) { // Go through items in each order
                orderDetails += item.getName() + " (" + item.getQuantity() + ") - $" + item.getPrice() + "<br>"; // Item details
            }
            double totalOrderSales = order.getItems().stream().mapToDouble(item -> item.getPrice() * item.getQuantity()).sum(); // Total sales for the order
            orderDetails += "Total Order Sales: $" + totalOrderSales + "</html>"; // Append total sales to order details
            ordersListModel.addElement(orderDetails); // Add order details to the list model
        }
    }

    // Method to calculate total sales
    private void calculateTotalSales() {
        double totalSales = 0; // Initialize total sales
        for (Order order : orders) { // Go through all orders
            for (Item item : order.getItems()) { // Go through items in each order
                totalSales += item.getPrice() * item.getQuantity(); // Calculate total sales
            }
        }
        lblTotalSales.setText("Total Sales: $" + totalSales); // Set total sales label
    }
}
