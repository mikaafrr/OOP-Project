package gui;

import javax.swing.JPanel;
import controller.MainFrame;
import data.Item;
import data.Order;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import Utility.Time;
import javax.swing.border.LineBorder;

public class MenuScreen extends JPanel {
    private MainFrame main;
    
    String loggedInCust;
    
    private JButton btnCheckout;
    
    private JButton btnFood1, btnFood2, btnFood3, btnFood4, btnFood5, btnFood6;
    private JButton btnDrink1, btnDrink2, btnDrink3, btnDrink4, btnDrink5, btnDrink6;
    private JButton btnSelPizza, btnSelDrink;
    
    private Item[] items;
    int lastOrderID;
    private int option;
    private int idNo;
    private String selectedImagePath;
    private Vector<Order> order;
    private List<Item> selectedItems = new ArrayList<>();
    private JLabel lblWelcome;
    
    private JLabel lblFood1, lblFood2, lblFood3, lblFood4, lblFood5, lblFood6;
    private JLabel lblDrink1, lblDrink2, lblDrink3, lblDrink4, lblDrink6, lblDrink5;
    private JLabel lblPizzas, lblDrinks;
    private JButton btnPizza;
    private JButton btnDrinks;

    public MenuScreen(MainFrame main) {
        setBorder(new LineBorder(new Color(0, 0, 0), 2)); // Set the border of the panel
        this.order = new Vector<>(); // Initialize the order vector
        this.lastOrderID = 000; // Initialize the last order ID
        this.main = main; // Set the main frame
        setLayout(null); // Set the layout to null

        // Create and add the menu label
        JLabel lblMenu = new JLabel("Temasek Pizza Menu!");
        lblMenu.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblMenu.setBounds(10, 11, 307, 36);
        add(lblMenu);

        // Create and add the checkout button
        this.btnCheckout = new JButton("Checkout Order");
        btnCheckout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                List<Item> cartItems = main.getController().getCartItems(); // Get items in the cart
                if (!cartItems.isEmpty()) {
                    main.getController().applyDiscount(); // Apply discount if applicable
                    int idNo = main.getController().genOrderID(); // Generate a new order ID
                    String time = Time.getCurrentTime(); // Get the current time
                    String orderID = "OrderID" + idNo; // Create the order ID string
                    List<Item> orderItems = new ArrayList<>(cartItems); // Create a list of order items
                    main.getController().addOrder(orderItems, orderID, main.getController().getLoggedInCustomer().getName()); // Add the order

                    // Create a message to display the order details
                    StringBuilder message = new StringBuilder("Checkout Successful!\n");
                    double total = 0.0;
                    for (Item item : orderItems) {
                        message.append(item.getName()).append(" (Qty: ").append(item.getQuantity()).append(")\n");
                        total += item.getQuantity() * item.getPrice();
                    }
                    message.append("Total Amount: $").append(total);
                    message.append("\nOrder ID: ").append(orderID);
                    message.append("\nTime Ordered: ").append(time);

                    JOptionPane.showMessageDialog(MenuScreen.this, message.toString()); // Show the order details
                    main.getController().clearCart(); // Clear the cart after checkout
                } else {
                    JOptionPane.showMessageDialog(MenuScreen.this, "No items in the order."); // Show message if no items in the cart
                }
            }
        });
        btnCheckout.setForeground(Color.RED);
        btnCheckout.setFont(new Font("Tahoma", Font.BOLD, 28));
        btnCheckout.setBounds(30, 836, 287, 78);
        add(btnCheckout);

        // Create and add the edit order button
        JButton btnEditOrder = new JButton("Edit Order");
        btnEditOrder.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                main.editOrderScreen(); // Show the edit order screen
            }
        });
        btnEditOrder.setFont(new Font("Tahoma", Font.BOLD, 28));
        btnEditOrder.setBounds(30, 742, 287, 78);
        add(btnEditOrder);

        // Create and add the logout button
        JButton btnLogOut = new JButton("Log Out");
        btnLogOut.setFont(new Font("Tahoma", Font.BOLD, 28));
        btnLogOut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                main.getController().clearCart(); // Clear the cart on logout
                main.showLoginScreen(); // Show the login screen
            }
        });
        btnLogOut.setBounds(1565, 836, 287, 78);
        add(btnLogOut);

        // Create and add the welcome label
        this.lblWelcome = new JLabel("Welcome, ");
        lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 20));
        loggedInCust = main.getController().getLoggedInCustomer().getName(); // Get logged-in customer name from controller
        lblWelcome.setBounds(1593, 11, 259, 78);
        lblWelcome.setText("Welcome, " + loggedInCust);
        add(lblWelcome);

        // Initialize and add food buttons
        btnFood1 = new JButton("");
        btnFood1.setBounds(10, 120, 156, 151);
        btnFood1.setVisible(false);
        add(btnFood1);

        btnFood2 = new JButton("");
        btnFood2.setBounds(251, 120, 156, 151);
        btnFood2.setVisible(false);
        add(btnFood2);

        btnFood3 = new JButton("");
        btnFood3.setBounds(487, 120, 156, 151);
        btnFood3.setVisible(false);
        add(btnFood3);

        btnFood4 = new JButton("");
        btnFood4.setBounds(728, 120, 156, 151);
        btnFood4.setVisible(false);
        add(btnFood4);
        
        btnFood5 = new JButton("");
        btnFood5.setBounds(980, 120, 156, 151);
        btnFood5.setVisible(false);
        add(btnFood5);
        
        btnFood6 = new JButton("");
        btnFood6.setBounds(1236, 120, 156, 151);
        btnFood6.setVisible(false);
        add(btnFood6);

        // Initialize and add drink buttons
        btnDrink1 = new JButton("");
        btnDrink1.setBounds(10, 413, 156, 151);
        btnDrink1.setVisible(false);
        add(btnDrink1);

        btnDrink2 = new JButton("");
        btnDrink2.setBounds(251, 413, 156, 151);
        btnDrink2.setVisible(false);
        add(btnDrink2);

        btnDrink3 = new JButton("");
        btnDrink3.setBounds(487, 413, 156, 151);
        btnDrink3.setVisible(false);
        add(btnDrink3);

        btnDrink4 = new JButton("");
        btnDrink4.setBounds(728, 413, 156, 151);
        btnDrink4.setVisible(false);
        add(btnDrink4);
        
        btnDrink5 = new JButton("");
        btnDrink5.setBounds(980, 413, 156, 151);
        btnDrink5.setVisible(false);
        add(btnDrink5);
        
        btnDrink6 = new JButton("");
        btnDrink6.setBounds(1236, 413, 156, 151);
        btnDrink6.setVisible(false);
        add(btnDrink6);
        
        // Create and add labels for Pizzas and Drinks
        lblPizzas = new JLabel("Pizzas:");
        lblPizzas.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblPizzas.setBounds(15, 84, 175, 20);
        lblPizzas.setVisible(false);
        add(lblPizzas);
        
        lblDrinks = new JLabel("Drinks:");
        lblDrinks.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblDrinks.setBounds(10, 377, 121, 20);
        lblDrinks.setVisible(false);
        add(lblDrinks);
        
        // Initialize and add labels for food and drinks
        lblFood1 = new JLabel("");
        lblFood1.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood1.setBounds(10, 284, 149, 45);
        add(lblFood1);
        
        lblFood2 = new JLabel("");
        lblFood2.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood2.setBounds(251, 284, 156, 45);
        add(lblFood2);
        
        lblFood3 = new JLabel("");
        lblFood3.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood3.setBounds(487, 284, 156, 45);
        add(lblFood3);
        
        lblFood4 = new JLabel("");
        lblFood4.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood4.setBounds(728, 284, 156, 45);
        add(lblFood4);
        
        lblFood5 = new JLabel("");
        lblFood5.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood5.setBounds(980, 284, 156, 45);
        add(lblFood5);
        
        lblFood6 = new JLabel("");
        lblFood6.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblFood6.setBounds(1236, 284, 156, 45);
        add(lblFood6);
        
        lblDrink1 = new JLabel("");
        lblDrink1.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblDrink1.setBounds(10, 580, 149, 45);
        add(lblDrink1);
        
        lblDrink2 = new JLabel("");
        lblDrink2.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblDrink2.setBounds(251, 580, 156, 45);
        add(lblDrink2);
        
        lblDrink3 = new JLabel("");
        lblDrink3.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblDrink3.setBounds(487, 580, 156, 45);
        add(lblDrink3);
        
        lblDrink4 = new JLabel("");
        lblDrink4.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblDrink4.setBounds(728, 580, 156, 45);
        add(lblDrink4);
        
        lblDrink5 = new JLabel("");
        lblDrink5.setBounds(980, 580, 156, 45);
        lblDrink5.setFont(new Font("Tahoma", Font.BOLD, 18));
        add(lblDrink5);
        
        lblDrink6 = new JLabel("");
        lblDrink6.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblDrink6.setBounds(1236, 580, 156, 45);
        add(lblDrink6);
        
        // Create and add buttons for selecting pizzas and drinks
        btnSelPizza = new JButton("Pizza");
        btnSelPizza.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                populatePizzaButtons(); // Populate the pizza buttons
            }
        });
        btnSelPizza.setFont(new Font("Tahoma", Font.BOLD, 30));
        btnSelPizza.setBounds(1558, 120, 156, 151);
        add(btnSelPizza);
        
        btnSelDrink = new JButton("Drinks");
        btnSelDrink.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                populateDrinkButtons(); // Populate the drink buttons
            }
        });
        btnSelDrink.setFont(new Font("Tahoma", Font.BOLD, 30));
        btnSelDrink.setBounds(1558, 413, 156, 151);
        add(btnSelDrink);

        this.populateJList(); // Populate the JList with all items
    }

    // Clear the selected items order
    private void clearItemsOrder() {
        selectedItems.clear();
    }

    // Populate the JList with all items
    private void populateJList() {
        this.items = this.main.getController().getAllItems(); // Get all items from the controller
        DefaultListModel model = new DefaultListModel(); // Create a new DefaultListModel
        for (int i = 0; i < items.length; i++) {
            Item it = items[i];
            model.addElement(it.getName() + " " + it.getPrice() + " " + " " + it.getQuantity()); // Add each item to the model
        }
    }

    // Create a copy of the item list
    private List<Item> copyItemList(List<Item> items) {
        List<Item> copy = new ArrayList<>(); // Create a new list to hold the copied items
        for (Item item : items) {
            copy.add(new Item(item.getName(), item.getPrice(), item.getQuantity(), item.getImagePath())); // Add each item to the new list
        }
        return copy;
    }

    // Populate the pizza buttons with the available pizzas
    private void populatePizzaButtons() {
        JButton[] foodButtons = { btnFood1, btnFood2, btnFood3, btnFood4, btnFood5, btnFood6 };    
        JLabel[] foodLbl = { lblFood1, lblFood2, lblFood3, lblFood4, lblFood5, lblFood6 };

        JButton[] drinkButtons = { btnDrink1, btnDrink2, btnDrink3, btnDrink4, btnDrink5, btnDrink6 };
        JLabel[] drinkLbl = { lblDrink1, lblDrink2, lblDrink3, lblDrink4, lblDrink5, lblDrink6 };

        int drinkIndex = 0;
        int foodIndex = 0;

        lblPizzas.setVisible(true); // Show the pizzas label
        lblDrinks.setVisible(false); // Hide the drinks label

        // Hide all drink buttons and labels
        for (int i = 0; i < drinkButtons.length; i++) {
            drinkButtons[i].setVisible(false);
            drinkLbl[i].setVisible(false);
        }

        // Populate the pizza buttons
        for (Item item : items) {
            if (item.getPrice() > 5) {
                if (foodIndex < foodButtons.length) {
                    foodButtons[foodIndex].setIcon(new ImageIcon(item.getImagePath())); // Set the icon for the button
                    foodButtons[foodIndex].setText("<html>" + item.getName() + "<br>$" + item.getPrice() + "<br>Qty: " + item.getQuantity() + "</html>"); // Set the text for the button
                    foodLbl[foodIndex].setText(item.getName()); // Set the label text
                    foodButtons[foodIndex].setVisible(true); // Show the button
                    foodLbl[foodIndex].setVisible(true); // Show the label
                    
                    // Remove existing action listeners
                    for (ActionListener al : foodButtons[foodIndex].getActionListeners()) {
                        foodButtons[foodIndex].removeActionListener(al);
                    }
                    foodButtons[foodIndex].addActionListener(e -> main.showMakeAMealScreen(item)); // Add a new action listener
                    foodIndex++;
                }
            } 
        }
    }

    // Populate the drink buttons with the available drinks
    private void populateDrinkButtons() {
        JButton[] foodButtons = { btnFood1, btnFood2, btnFood3, btnFood4, btnFood5, btnFood6 };    
        JLabel[] foodLbl = { lblFood1, lblFood2, lblFood3, lblFood4, lblFood5, lblFood6 };

        JButton[] drinkButtons = { btnDrink1, btnDrink2, btnDrink3, btnDrink4, btnDrink5, btnDrink6 };
        JLabel[] drinkLbl = { lblDrink1, lblDrink2, lblDrink3, lblDrink4, lblDrink5, lblDrink6 };

        int drinkIndex = 0;
        int foodIndex = 0;

        lblDrinks.setVisible(true); // Show the drinks label
        lblPizzas.setVisible(false); // Hide the pizzas label

        // Hide all food buttons and labels
        for (int i = 0; i < foodButtons.length; i++) {
            foodButtons[i].setVisible(false);
            foodLbl[i].setVisible(false);
        }

        // Populate the drink buttons
        for (Item item : items){
            if (item.getPrice() <= 5) {
                if (drinkIndex < drinkButtons.length) {
                    drinkButtons[drinkIndex].setIcon(new ImageIcon(item.getImagePath())); // Set the icon for the button
                    drinkButtons[drinkIndex].setText("<html>" + item.getName() + "<br>$" + item.getPrice() + "<br>Qty: " + item.getQuantity() + "</html>"); // Set the text for the button
                    drinkLbl[drinkIndex].setText(item.getName()); // Set the label text
                    drinkButtons[drinkIndex].setVisible(true); // Show the button
                    drinkLbl[drinkIndex].setVisible(true); // Show the label
                    
                    // Remove existing action listeners
                    for (ActionListener al : drinkButtons[drinkIndex].getActionListeners()) {
                        drinkButtons[drinkIndex].removeActionListener(al);
                    }
                    drinkButtons[drinkIndex].addActionListener(e -> main.showCheckOrderScreen(null, item)); // Add a new action listener
                    drinkIndex++;
                }
            }
        }
    }
}
