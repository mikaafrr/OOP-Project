package data;

import java.util.List;
import java.util.Vector;

public class Order {
	
	private Vector<Order> orders;
	private List<Item> items;
	private String orderID;
	private String createdByCustomer;
	
	public Order(List<Item> selectedItems, String orderID2, String loggedInCust) {
		this.items = selectedItems;
		this.orderID=orderID2;
		this.createdByCustomer=loggedInCust;
	}

	public List<Item> getItems(){
		return items;
	}
	
	public void setItems(List<Item> items){
		this.items = items;
	}
	
	public String getOrderID(){
		return orderID;
	}
	
	public void setOrderID(String orderID){
		this.orderID = orderID;
	}
	
	public String getCreatedByCustomer(){
		return createdByCustomer;
	}
	
	public void setCreatedByCustomer(String createdByCustomer){
		this.createdByCustomer = createdByCustomer;
	}
	
	public void addOrder(Order order){
		orders.add(order);
	}
	
	public Order getOrder(String orderID){
		for (Order order : orders){
			if(order.getOrderID().equals(orderID)){
				return order;
			}
		}
		return null;
	}
}
