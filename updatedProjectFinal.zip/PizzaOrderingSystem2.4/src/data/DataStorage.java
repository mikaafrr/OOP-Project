package data;

import java.util.Vector;

public class DataStorage {
    // Vectors to store different types of data
    Vector<Customer> storageCust = new Vector<Customer>();
    Vector<Staff> storageStaff = new Vector<Staff>();
    Vector<Item> storageItem = new Vector<Item>();
    Vector<Order> storageOrder = new Vector<Order>();

    // Constructor to initialize the storage with some default values
    public DataStorage(){
        // Adding default customers
        storageCust.add(new Customer("Famous", "2323"));
        
        // Adding default staff
        storageStaff.add(new Staff("Aryan", "Mika"));
        
        // Adding default items (pizzas and drinks)
        storageItem.add(new Item("Cheese Pizza", 10.50, 10, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\cheesePizza.jpeg"));
        storageItem.add(new Item("Bacon Pizza", 12.50, 15, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\baconPizza.jpeg"));
        storageItem.add(new Item("Veggie Pizza", 8.50, 10, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\veggiePizza.jpeg"));
        storageItem.add(new Item("Hawaiian Pizza", 13.0, 15, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\hawaiianPizza.jpeg"));
        
        storageItem.add(new Item("Milo", 3.5, 10, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\milo.jpeg"));
        storageItem.add(new Item("Orange Juice", 2.5, 5, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\oj.jpeg"));
        storageItem.add(new Item("Water", 1.2, 15, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\water.jpeg"));
        storageItem.add(new Item("Coffee", 2.0, 10, "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\images\\coffee.jpeg"));
    }

    // Method to store a customer in the vector
    public void storeCustomer(Customer c) {
        this.storageCust.add(c);
    }

    // Method to get all customers as an array
    public Customer[] getAllCustomers() {
        Customer[] opArrCustomer = new Customer[this.storageCust.size()];
        this.storageCust.toArray(opArrCustomer);
        return opArrCustomer;
    }

    // Method to store a staff member in the vector
    public void storeStaff(Staff s) {
        this.storageStaff.add(s);
    }

    // Method to get all staff members as an array
    public Staff[] getAllStaff() {
        Staff[] opArrStaff = new Staff[this.storageStaff.size()];
        this.storageStaff.toArray(opArrStaff);
        return opArrStaff;
    }

    // Method to find a customer by name
    public Customer getCustomer(String n) {
        for (int i = 0; i < storageCust.size(); i++) {
            Customer temp = storageCust.get(i);
            if (temp.getName().equals(n)) {
                return temp;
            }
        }
        return null;
    }

    // Method to find a staff member by name
    public Staff getStaff(String n) {
        for (int i = 0; i < storageStaff.size(); i++) {
            Staff temp = storageStaff.get(i);
            if (temp.getName().equals(n)) {
                return temp;
            }
        }
        return null;
    }

    // Method to store an item in the vector
    public void storeItem(Item item) {
        this.storageItem.add(item);
    }

    // Method to get all items as an array
    public Item[] getAllItems() {
        Item[] opArr = new Item[this.storageItem.size()];
        this.storageItem.toArray(opArr);
        return opArr;
    }

    // Method to store an order in the vector
    public void storeOrder(Order order) {
        this.storageOrder.add(order);
    }

    // Method to get all orders as an array
    public Order[] getAllOrders() {
        Order[] opArr = new Order[this.storageOrder.size()];
        this.storageOrder.toArray(opArr);
        return opArr;
    }

    // Method to edit an item at a specific index
    public void editItems(int index, Item newItem) {
        this.storageItem.set(index, newItem);
    }

    // Method to delete an order at a specific index
    public void deleteOrder(int index) {
        this.storageOrder.remove(index);
    }

    // Method to edit an order at a specific index
    public void editOrder(int index, Order order) {
        this.storageOrder.set(index, order);
    }

    // Method to delete an item at a specific index
    public void deleteItem(int index) {
        this.storageItem.remove(index);
    }
}
