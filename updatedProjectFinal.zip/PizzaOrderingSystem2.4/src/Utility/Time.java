package Utility;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Time {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");

    public static String getCurrentTime() {
        Date now = new Date(System.currentTimeMillis());
        String date = DATE_FORMAT.format(now);
        String time = TIME_FORMAT.format(now);
        return date + " " + time;
    }
    public static String getCurrentDate() {
        Date now = new Date(System.currentTimeMillis());
        return DATE_FORMAT.format(now);
    }
}
