package Utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.*;

public class ReadWriteExcel {
    // Path to the Excel file
    private String filePath = "C:\\Users\\famou\\OneDrive\\Desktop\\YEAR 2\\Sem1\\OOP\\ProjectFolderVersions\\CustomerOOP.xlsx";

    // Method to get the row count of a specified sheet
    public int getRowCount(String sheetName) {
        int rowCount = 0;
        try (FileInputStream fis = new FileInputStream(filePath); // Open the Excel file
             Workbook wb = WorkbookFactory.create(fis)) { // Create a workbook instance

            Sheet sheet = wb.getSheet(sheetName); // Get the sheet by name
            if (sheet != null) {
                rowCount = sheet.getLastRowNum() + 1; // Get the last row number (+1 as rows are 0-indexed)
            }
        } catch (Exception e) {
            System.out.println("Error reading Excel file"); // Print error message if any exception occurs
            e.printStackTrace(); // Print the stack trace for debugging
        }
        return rowCount; // Return the row count
    }

    // Method to read a cell value from the Excel file
    public String ReadExcel(String sheetName, int rNum, int cNum) {
        String data = "";
        try (FileInputStream fis = new FileInputStream(filePath); // Open the Excel file
             Workbook wb = WorkbookFactory.create(fis)) { // Create a workbook instance

            Sheet sheet = wb.getSheet(sheetName); // Get the sheet by name
            Row row = sheet.getRow(rNum); // Get the row by row number
            if (row != null) {
                Cell cell = row.getCell(cNum); // Get the cell by column number
                if (cell != null) {
                    data = cell.getStringCellValue(); // Get the cell value as a string
                }
            }
        } catch (Exception e) {
            System.out.println("ReadExcel catch block"); // Print error message if any exception occurs
            e.printStackTrace(); // Print the stack trace for debugging
        }
        return data; // Return the cell value
    }
    
    // Method to write a new row to the Excel file
    public void WriteExcel(String sheetName, String username, String password) {
        try (FileInputStream fis = new FileInputStream(filePath); // Open the Excel file
             Workbook wb = WorkbookFactory.create(fis)) { // Create a workbook instance
             
            Sheet sheet = wb.getSheet(sheetName); // Get the sheet by name
            
            // Get the last row number and create a new row
            int rowCount = sheet.getLastRowNum();
            Row row = sheet.createRow(rowCount + 1);

            // Set the username and password in the new row
            Cell cell1 = row.createCell(0); // Create the first cell in the row
            cell1.setCellValue(username); // Set the username value
            Cell cell2 = row.createCell(1); // Create the second cell in the row
            cell2.setCellValue(password); // Set the password value
            
            // Write the changes to the file
            try (FileOutputStream fos = new FileOutputStream(filePath)) { // Open the file output stream
                wb.write(fos); // Write the workbook to the file
            }
        } catch (Exception e) {
            System.out.println("WriteExcel catch block"); // Print error message if any exception occurs
            e.printStackTrace(); // Print the stack trace for debugging
        }
    }
}
