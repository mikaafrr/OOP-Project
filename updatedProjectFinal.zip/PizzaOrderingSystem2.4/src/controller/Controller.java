package controller;

import data.Customer;
import data.DataStorage;
import data.Item;
import data.Order;
import data.Staff;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Utility.ReadWriteExcel;

public class Controller {
    private ReadWriteExcel excelHandler = new ReadWriteExcel(); // Handler for reading/writing Excel files
    private DataStorage ds = new DataStorage(); // Data storage instance for managing data
    private int idNo; // Variable to generate unique order IDs
    private Customer loggedInCustomer; // Currently logged-in customer
    private List<Item> cart; // Shopping cart to hold selected items

    // Method to load customers from Excel file
    public void loadCustomersFromExcel() {
        String sheetName = "Customer_Credentials"; // Name of the sheet in Excel
        int rowCount = excelHandler.getRowCount(sheetName); // Get the number of rows in the sheet

        // Iterate through each row in the sheet
        for (int rowNum = 1; rowNum < rowCount; rowNum++) {
            String username = excelHandler.ReadExcel(sheetName, rowNum, 0); // Read username from Excel
            String password = excelHandler.ReadExcel(sheetName, rowNum, 1); // Read password from Excel

            // If username and password are not empty, create a new customer and store it
            if (!username.isEmpty() && !password.isEmpty()) {
                Customer customer = new Customer(username, password);
                ds.storeCustomer(customer);
            }
        }
    }

    // Method to register new customers
    public void registerCustomers(String user, String pass) {
        Customer customer = new Customer(user, pass); // Create a new customer
        this.ds.storeCustomer(customer); // Store customer in data storage
        excelHandler.WriteExcel("Customer_Credentials", user, pass); // Write customer credentials to Excel
    }

    // Method to register new staff members
    public void registerStaff(String user, String pass) {
        Staff staff = new Staff(user, pass); // Create a new staff member
        this.ds.storeStaff(staff); // Store staff member in data storage
    }

    // Method to verify customer credentials
    public boolean verifyCustomer(String n, String p) {
        Customer t = ds.getCustomer(n); // Get customer by name
        if (t != null && t.getPassword().equals(p)) { // Check if customer exists and password matches
            setLoggedInCustomer(t); // Set the logged-in customer
            return true;
        }
        return false;
    }

    // Method to verify staff credentials
    public boolean verifyStaff(String n, String p) {
        Staff t = ds.getStaff(n); // Get staff by name
        return t != null && t.getPassword().equals(p); // Check if staff exists and password matches
    }

    // Method to get all customers
    public Customer[] getAllCustomers() {
        return this.ds.getAllCustomers();
    }

    // Method to get all staff members
    public Staff[] getAllStaff() {
        return this.ds.getAllStaff();
    }

    // Method to add a new item
    public void addItem(String name, double price, int quantity, String imagePath) {
        Item item = new Item(name, price, quantity, imagePath); // Create a new item
        this.ds.storeItem(item); // Store item in data storage
    }

    // Method to get all items
    public Item[] getAllItems() {
        return this.ds.getAllItems();
    }

    // Method to add a new order
    public void addOrder(List<Item> items, String orderID, String createdByCustomer) {
        Order order = new Order(items, orderID, createdByCustomer); // Create a new order
        this.ds.storeOrder(order); // Store order in data storage

        // Update item quantities after the order is placed
        for (Item orderedItem : items) {
            Item existingItem = findItemByName(orderedItem.getName());
            if (existingItem != null) {
                int newQuantity = existingItem.getQuantity() - orderedItem.getQuantity();
                if (newQuantity < 0) {
                    newQuantity = 0;
                }
                existingItem.setQuantity(newQuantity);
                editItems(findItemIndex(existingItem), existingItem); // Edit the item in data storage
            }
        }
    }

    // Method to get all orders
    public Order[] getAllOrders() {
        return this.ds.getAllOrders();
    }

    // Method to edit an item
    public void editItems(int index, Item newItem) {
        this.ds.editItems(index, newItem); // Edit item in data storage
    }

    // Method to edit an order
    public void editOrder(int index, Order order) {
        this.ds.editOrder(index, order); // Edit order in data storage
    }

    // Method to generate a unique order ID
    public int genOrderID() {
        idNo = idNo + 1; // Increment the ID number
        return idNo;
    }

    // Method to clear items from a list
    public void clearItems(List<Item> test) {
        test.clear(); // Clear the list
    }

    // Method to delete an order
    public void deleteOrder(int index) {
        this.ds.deleteOrder(index); // Delete order from data storage
    }

    // Method to find an item by name
    public Item findItemByName(String itemName) {
        Item[] allItems = getAllItems(); // Get all items
        for (Item item : allItems) {
            if (item.getName().equals(itemName)) { // Check if item name matches
                return item;
            }
        }
        return null; // Return null if item not found
    }

    // Method to delete an item
    public void deleteItem(int index) {
        this.ds.deleteItem(index); // Delete item from data storage
    }

    // Method to check if an item exists
    public boolean itemExists(String itemName) {
        Item[] allItems = ds.getAllItems(); // Get all items
        for (Item item : allItems) {
            if (item != null && itemName.equals(item.getName())) { // Check if item name matches
                return true;
            }
        }
        return false;
    }

    // Method to get all drinks
    public Item[] getDrinks() {
        Item[] allItems = getAllItems(); // Get all items
        List<Item> drinksList = new ArrayList<>(); // List to hold drinks
        for (Item item : allItems) {
            if (item.getPrice() <= 5) { // Check if item is a drink
                drinksList.add(item);
            }
        }
        return drinksList.toArray(new Item[0]); // Convert list to array and return
    }
    
    // Method to set the logged-in customer
    public void setLoggedInCustomer(Customer customer) {
        this.loggedInCustomer = customer;
    }

    // Method to get the logged-in customer
    public Customer getLoggedInCustomer() {
        return this.loggedInCustomer;
    }
    
    // Method to find the index of an item in the item list
    public int findItemIndex(Item item) {
        Item[] allItems = getAllItems(); // Get all items
        for (int i = 0; i < allItems.length; i++) {
            if (allItems[i].getName().equals(item.getName())) { // Check if item name matches
                return i;
            }
        }
        return -1; // Return -1 if item not found
    }
    
    // Method to initialize the shopping cart
    public void initialiseCart() {
        this.cart = new ArrayList<>(); // Initialize cart as an ArrayList
    }
    
    // Method to add an item to the cart
    public void addToCart(Item item) {
        if (this.cart == null) {
            initialiseCart(); // Initialize cart if it is null
        }
        cart.add(item); // Add item to the cart
    }
    
    // Method to get all items in the cart
    public List<Item> getCartItems() {
        if (this.cart == null) {
            initialiseCart(); // Initialize cart if it is null
        }
        return new ArrayList<>(cart); // Return a new list containing all cart items
    }
    
    // Method to clear the cart
    public void clearCart() {
        if (this.cart != null) {
            cart.clear(); // Clear the cart
        }
    }
    
    // Method to apply discount to the cart
    public void applyDiscount() {
        boolean hasMeal = false; // Flag to check if cart has a meal
        Item drinkItem = null; // Variable to hold a drink item

        // Iterate through items in the cart
        for (Item item : cart) {
            if (item.getPrice() > 5) {
                hasMeal = true; // Set flag if item is a meal
            } else if (item.getPrice() <= 5) {
                drinkItem = item; // Set drink item if item is a drink
            }
        }

        // Apply discount if cart has a meal and a drink
        if (hasMeal && drinkItem != null) {
            double originalPrice = drinkItem.getPrice(); // Get original price of drink
            double discountedPrice = originalPrice * 0.7; // Calculate discounted price
            drinkItem.setPrice(discountedPrice); // Set discounted price for drink
        }
    }
}
