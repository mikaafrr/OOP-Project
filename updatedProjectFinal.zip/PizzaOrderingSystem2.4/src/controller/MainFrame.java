package controller;

import java.awt.CardLayout;
import javax.swing.JFrame;

import data.Item;
import gui.AdminScreen;
import gui.CheckOrderScreen;
import gui.EditItemScreen;
import gui.EditOrderScreen;
import gui.InventoryScreen;
import gui.LoginScreen;
import gui.MakeAMealScreen;
import gui.MenuScreen;
import gui.RegisterScreen;
import gui.SummaryScreen;

public class MainFrame extends JFrame {
    private Controller controller;
    private CardLayout card;
    private MenuScreen menuscreen;
    private MakeAMealScreen makeamealscreen;
    private CheckOrderScreen checkorderscreen;

    public MainFrame() {
        this.setTitle("Temasek Pizzas");
        this.setSize(1920, 1080);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.card = new CardLayout();
        this.setLayout(this.card);
        this.controller = new Controller();

        // Load data from Excel
        this.controller.loadCustomersFromExcel();
        

        this.showLoginScreen();
        this.setVisible(true);
    }

    public void showLoginScreen() {
        LoginScreen p1 = new LoginScreen(this);
        this.add(p1, "Panel1");
        this.card.show(this.getContentPane(), "Panel1");
    }

    public void showRegisterScreen() {
        RegisterScreen p2 = new RegisterScreen(this);
        this.add(p2, "Panel2");
        this.card.show(this.getContentPane(), "Panel2");
    }

    public void showMenuScreen() {
        MenuScreen p3 = new MenuScreen(this);
        this.add(p3, "Panel3");
        this.card.show(this.getContentPane(), "Panel3");
    }

    public void showAdminScreen() {
        AdminScreen p4 = new AdminScreen(this);
        this.add(p4, "Panel4");
        this.card.show(this.getContentPane(), "Panel4");
    }

    public void editOrderScreen() {
        EditOrderScreen p5 = new EditOrderScreen(this);
        this.add(p5, "Panel5");
        this.card.show(this.getContentPane(), "Panel5");
    }

    public void showEditItemScreen() {
        EditItemScreen p6 = new EditItemScreen(this);
        this.add(p6, "Panel6");
        this.card.show(this.getContentPane(), "Panel6");
    }

    public void showSummaryScreen() {
        SummaryScreen p7 = new SummaryScreen(this);
        this.add(p7, "Panel7");
        this.card.show(this.getContentPane(), "Panel7");
    }

    public void showInventoryScreen() {
        InventoryScreen p8 = new InventoryScreen(this);
        this.add(p8, "Panel8");
        this.card.show(this.getContentPane(), "Panel8");
    }
    

    public void showMakeAMealScreen(Item item) {
        MakeAMealScreen p9 = new MakeAMealScreen(this, item); // Create make a meal screen instance
        this.add(p9, "Panel9");
        this.card.show(this.getContentPane(), "Panel9"); 
    }
    
    
    public void showCheckOrderScreen(Item foodItem, Item drinkItem) {
        CheckOrderScreen p10 = new CheckOrderScreen(this, foodItem, drinkItem); // Create check order screen instance
        this.add(p10, "Panel10"); 
        this.card.show(this.getContentPane(), "Panel10"); 
    }



    public static void main(String[] args) {
        MainFrame ex = new MainFrame();
    }

    public Controller getController() {
        return this.controller;
    }
}
